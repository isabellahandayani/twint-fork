# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['twint', 'twint.storage']

package_data = \
{'': ['*']}

install_requires = \
['PySocks>=1.7.1,<2.0.0',
 'aiodns>=3.0.0,<4.0.0',
 'aiohttp-socks<=0.4.1',
 'aiohttp==3.7.0',
 'beautifulsoup4>=4.10.0,<5.0.0',
 'cchardet>=2.1.7,<3.0.0',
 'elasticsearch>=8.0.1,<9.0.0',
 'fake-useragent>=0.1.11,<0.2.0',
 'geopy>=2.2.0,<3.0.0',
 'psycopg2-binary>=2.9.1',
 'pydantic>=1.9.0,<2.0.0',
 'schedule>=1.1.0,<2.0.0']

setup_kwargs = {
    'name': 'twint',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Muhammad Daffa Dinaya',
    'author_email': '13518141@std.stei.itb.ac.id',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
